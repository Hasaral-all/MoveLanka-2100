import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { JourneyProvider } from './contexts/JourneyContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { useScreenInit } from './useScreenInit.js';
import { Home } from './pages/Home';
import { RouteDetails } from './pages/RouteDetails';
import { LiveTracking } from './pages/LiveTracking';

interface AppProps {
  /** Which colour mode the app opens in. Users can switch it at any time. */
  theme?: 'light' | 'dark';
  /** Start in the high-contrast accessibility theme. */
  highContrast?: boolean;
  /** Start with the large text accessibility setting on. */
  largeText?: boolean;
  /** Simulate a 6 minute delay so the AI smart routing suggestion appears. */
  simulateDelay?: boolean;
}

interface ScreenInit {
  theme?: 'light' | 'dark';
  highContrast?: boolean;
  largeText?: boolean;
}

export function App({ theme = 'light', highContrast = false, largeText = false, simulateDelay = true }: AppProps) {
  const screenInit = useScreenInit() as ScreenInit;

  return (
    <SettingsProvider
      initialTheme={screenInit.theme ?? theme}
      initialHighContrast={screenInit.highContrast ?? highContrast}
      initialLargeText={screenInit.largeText ?? largeText}>
      
      <JourneyProvider delayOnFastest={simulateDelay}>
        <BrowserRouter>
          <div className="min-h-full w-full bg-bg font-sans text-ink">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/journey" element={<RouteDetails />} />
              <Route path="/live" element={<LiveTracking />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </BrowserRouter>
      </JourneyProvider>
    </SettingsProvider>);

}