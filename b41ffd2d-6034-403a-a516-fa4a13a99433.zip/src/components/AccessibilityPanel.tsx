import React, { useState } from 'react';
import { ChevronDownIcon, SettingsIcon } from 'lucide-react';
import { AccessibilityBar } from './AccessibilityBar';

/** Collapsed accessibility controls for screens where they are a secondary action. */
export function AccessibilityPanel() {
  const [open, setOpen] = useState(false);

  return (
    <section className="rounded-2xl border border-line bg-surface">
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((prev) => !prev)}
        className="flex min-h-[60px] w-full items-center gap-3 px-4 text-left">
        
        <SettingsIcon className="h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
        <span className="flex-1 text-base font-bold text-ink">Accessibility options</span>
        <ChevronDownIcon
          className={`h-5 w-5 shrink-0 text-muted transition-transform duration-200 ease-smooth ${
          open ? 'rotate-180' : ''}`
          }
          aria-hidden="true" />
        
      </button>
      {open &&
      <div className="border-t border-line p-3">
          <AccessibilityBar embedded />
        </div>
      }
    </section>);

}