import React, { useMemo } from 'react';
import { ISLAND_OUTLINE } from '../data/network';
import { pointAlong, polylineLength, toPathD } from '../utils/geo';
import type { LiveState } from '../contexts/JourneyContext';
import type { MapPoint, Route } from '../types/journey';

interface SmartCityMapProps {
  route: Route;
  live: LiveState | null;
}

const C = {
  bg: 'rgb(var(--bg-rgb))',
  land: 'rgb(var(--map-land-rgb))',
  surface: 'rgb(var(--surface-rgb))',
  surface2: 'rgb(var(--surface-2-rgb))',
  line: 'rgb(var(--border-rgb))',
  text: 'rgb(var(--text-rgb))',
  muted: 'rgb(var(--muted-rgb))',
  accent: 'rgb(var(--accent-rgb))',
  info: 'rgb(var(--info-rgb))'
};

function islandPath(): string {
  return `${toPathD(ISLAND_OUTLINE)} Z`;
}

export function SmartCityMap({ route, live }: SmartCityMapProps) {
  const fullPath = useMemo<MapPoint[]>(
    () => route.legs.flatMap((leg, index) => index === 0 ? leg.path : leg.path.slice(1)),
    [route]
  );

  const viewBox = useMemo(() => {
    const xs = fullPath.map((p) => p.x);
    const ys = fullPath.map((p) => p.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);
    const width = Math.max(150, maxX - minX + 120);
    const height = Math.max(width * 0.72, maxY - minY + 110);
    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;
    return { x: cx - width / 2, y: cy - height / 2, width, height: Math.max(height, width * 0.72) };
  }, [fullPath]);

  const totalLength = useMemo(() => polylineLength(fullPath), [fullPath]);
  const travelled = totalLength * (live?.progress ?? 0);
  const vehicle = live ? pointAlong(live.leg.path, live.legFraction) : fullPath[0];
  const origin = fullPath[0];
  const destination = fullPath[fullPath.length - 1];
  const pathD = toPathD(fullPath);
  const unit = viewBox.width / 100;

  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-bg">
      <svg
        viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`}
        className="block h-auto w-full"
        role="img"
        aria-label={`Map of Sri Lanka showing the journey from ${route.origin} to ${route.destination}. ${Math.round(
          (live?.progress ?? 0) * 100
        )} percent complete. You are near ${live?.currentStop ?? route.origin}.`}>
        
        <rect x={viewBox.x} y={viewBox.y} width={viewBox.width} height={viewBox.height} fill={C.bg} />

        {Array.from({ length: 12 }).map((_, i) => {
          const step = viewBox.width / 8;
          const x = Math.floor(viewBox.x / step) * step + i * step;
          return (
            <line
              key={`v${i}`}
              x1={x}
              y1={viewBox.y}
              x2={x}
              y2={viewBox.y + viewBox.height}
              stroke={C.line}
              strokeWidth={0.3 * unit}
              opacity="0.35" />);


        })}
        {Array.from({ length: 12 }).map((_, i) => {
          const step = viewBox.width / 8;
          const y = Math.floor(viewBox.y / step) * step + i * step;
          return (
            <line
              key={`h${i}`}
              x1={viewBox.x}
              y1={y}
              x2={viewBox.x + viewBox.width}
              y2={y}
              stroke={C.line}
              strokeWidth={0.3 * unit}
              opacity="0.35" />);


        })}

        <path
          d={islandPath()}
          fill={C.land}
          stroke={C.line}
          strokeWidth={0.9 * unit}
          strokeLinejoin="round"
          opacity="0.95" />
        

        <path d={pathD} fill="none" stroke={C.surface2} strokeWidth={3.4 * unit} strokeLinecap="round" />
        <path d={pathD} fill="none" stroke={C.muted} strokeWidth={1.2 * unit} strokeLinecap="round" opacity="0.65" />
        <path
          d={pathD}
          fill="none"
          stroke={C.accent}
          strokeWidth={1.7 * unit}
          strokeLinecap="round"
          strokeDasharray={`${travelled} ${Math.max(0, totalLength - travelled)}`} />
        

        {route.legs.map((leg) =>
        leg.stops.map((stop, index) => {
          const point = leg.path[index];
          const isCurrent = live?.currentStop === stop;
          return (
            <circle
              key={`${leg.id}-${stop}-${index}`}
              cx={point.x}
              cy={point.y}
              r={(isCurrent ? 2.6 : 1.7) * unit}
              fill={isCurrent ? C.accent : C.surface}
              stroke={isCurrent ? C.accent : C.muted}
              strokeWidth={0.7 * unit} />);


        })
        )}

        <circle cx={origin.x} cy={origin.y} r={4 * unit} fill="none" stroke={C.info} strokeWidth={0.7 * unit} />
        <circle cx={origin.x} cy={origin.y} r={1.9 * unit} fill={C.info} />
        <text x={origin.x} y={origin.y + 7 * unit} fill={C.muted} fontSize={3.4 * unit} fontWeight="700" textAnchor="middle">
          {route.origin}
        </text>

        <circle cx={destination.x} cy={destination.y} r={2.6 * unit} fill={C.accent} />
        <text
          x={destination.x}
          y={destination.y - 4.6 * unit}
          fill={C.text}
          fontSize={3.6 * unit}
          fontWeight="800"
          textAnchor="middle">
          
          {route.destination}
        </text>

        {live &&
        <g>
            <circle cx={vehicle.x} cy={vehicle.y} r={5.4 * unit} fill={C.accent} opacity="0.22" />
            <circle
            cx={vehicle.x}
            cy={vehicle.y}
            r={3.1 * unit}
            fill={C.accent}
            stroke={C.bg}
            strokeWidth={1.1 * unit} />
          
          </g>
        }
      </svg>
    </div>);

}