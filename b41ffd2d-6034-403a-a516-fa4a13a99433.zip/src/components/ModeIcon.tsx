import React from 'react';
import { BusIcon, PlaneIcon, RouteIcon, TrainFrontIcon } from 'lucide-react';
import type { ModeKey } from '../types/journey';

const ICONS = {
  bus: BusIcon,
  train: TrainFrontIcon,
  air: PlaneIcon,
  road: RouteIcon
} as const;

interface ModeIconProps {
  mode: ModeKey;
  className?: string;
}

export function ModeIcon({ mode, className = 'h-5 w-5' }: ModeIconProps) {
  const Icon = ICONS[mode];
  return <Icon className={className} aria-hidden="true" />;
}