import React from 'react';
import { MoonIcon, SunIcon } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';

export function ThemeToggle({ className = '' }: {className?: string;}) {
  const { theme, toggleTheme } = useSettings();
  const dark = theme === 'dark';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-pressed={dark}
      className={`flex min-h-[48px] items-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-bold text-ink transition-colors duration-150 ease-smooth hover:border-accent ${className}`}>
      
      {dark ?
      <SunIcon className="h-5 w-5 text-accent" aria-hidden="true" /> :

      <MoonIcon className="h-5 w-5 text-accent" aria-hidden="true" />
      }
      {dark ? 'Light' : 'Dark'}
      <span className="sr-only">mode. Currently {dark ? 'dark' : 'light'} mode.</span>
    </button>);

}