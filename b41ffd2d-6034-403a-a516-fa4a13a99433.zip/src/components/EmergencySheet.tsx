import React, { useEffect, useRef } from 'react';
import { HeartPulseIcon, MapPinIcon, MessageSquareIcon, PhoneIcon, XIcon } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';

interface EmergencySheetProps {
  open: boolean;
  onClose: () => void;
  location: string;
  vehicle: string;
}

const ACTIONS = [
{ icon: PhoneIcon, label: 'Call 1919 emergency line', detail: 'Island response centre answers in seconds', urgent: true },
{ icon: HeartPulseIcon, label: 'Medical help on board', detail: 'Alerts the on-vehicle assistance crew', urgent: false },
{ icon: MessageSquareIcon, label: 'Talk to a travel host', detail: 'A real person, by voice or text', urgent: false }];


export function EmergencySheet({ open, onClose, location, vehicle }: EmergencySheetProps) {
  const { speak } = useSettings();
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    closeRef.current?.focus();
    speak('Assistance menu open. Help is one tap away.');
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose, speak]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <button type="button" aria-label="Close assistance menu" onClick={onClose} className="absolute inset-0 bg-black/60" />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="assist-title"
        className="relative w-full max-w-md rounded-t-3xl border border-line bg-surface p-5 pb-8 shadow-2xl">
        
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 id="assist-title" className="text-2xl font-extrabold text-ink">
              Need help?
            </h2>
            <p className="pt-1 text-sm text-muted">Choose one. Someone will answer straight away.</p>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            className="flex h-12 w-12 items-center justify-center rounded-xl border border-line bg-surface2 text-ink">
            
            <XIcon className="h-5 w-5" aria-hidden="true" />
            <span className="sr-only">Close</span>
          </button>
        </div>

        <ul className="space-y-3 pt-5">
          {ACTIONS.map(({ icon: Icon, label, detail, urgent }) =>
          <li key={label}>
              <button
              type="button"
              className={`flex min-h-[68px] w-full items-center gap-4 rounded-2xl border px-4 py-3 text-left ${
              urgent ? 'border-danger bg-danger/10' : 'border-line bg-surface2'}`
              }>
              
                <span
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                urgent ? 'bg-danger text-dangerInk' : 'bg-bg text-accent'}`
                }>
                
                  <Icon className="h-6 w-6" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span className="block text-base font-extrabold text-ink">{label}</span>
                  <span className="block text-sm leading-snug text-muted">{detail}</span>
                </span>
              </button>
            </li>
          )}
        </ul>

        <div className="mt-5 flex items-start gap-3 rounded-2xl border border-line bg-surface2 px-4 py-3">
          <MapPinIcon className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
          <p className="text-sm text-muted">
            Your live location is shared automatically: <span className="font-bold text-ink">{location}</span>, on{' '}
            <span className="font-bold text-ink">{vehicle}</span>.
          </p>
        </div>
      </div>
    </div>);

}