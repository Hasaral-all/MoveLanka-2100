import React from 'react';
import { SparklesIcon } from 'lucide-react';

interface AiAssistantCardProps {
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  tone?: 'default' | 'alert';
  children?: React.ReactNode;
}

export function AiAssistantCard({
  title,
  message,
  actionLabel,
  onAction,
  tone = 'default',
  children
}: AiAssistantCardProps) {
  const alert = tone === 'alert';
  return (
    <section
      aria-label={title}
      className={`rounded-2xl border p-4 ${alert ? 'border-warn bg-warn/[0.08]' : 'border-info/60 bg-info/[0.07]'}`}>
      
      <div className="flex items-start gap-3">
        <span
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
          alert ? 'bg-warn text-warnInk' : 'bg-info text-infoInk'}`
          }>
          
          <SparklesIcon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className={`text-base font-extrabold ${alert ? 'text-warn' : 'text-info'}`}>{title}</h2>
          <p className="pt-1 text-[0.95rem] leading-snug text-ink">{message}</p>
          {children}
        </div>
      </div>
      {actionLabel && onAction &&
      <button
        type="button"
        onClick={onAction}
        className={`mt-4 min-h-[52px] w-full rounded-xl px-4 text-base font-extrabold transition-colors duration-150 ease-smooth ${
        alert ? 'bg-warn text-warnInk hover:opacity-90' : 'bg-info text-infoInk hover:opacity-90'}`
        }>
        
          {actionLabel}
        </button>
      }
    </section>);

}