import React from 'react';
import { ContrastIcon, TypeIcon, Volume2Icon, WavesIcon } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import type { AccessibilitySettings } from '../contexts/SettingsContext';

interface Option {
  key: keyof AccessibilitySettings;
  label: string;
  icon: typeof TypeIcon;
}

const OPTIONS: Option[] = [
{ key: 'largeText', label: 'Large text', icon: TypeIcon },
{ key: 'highContrast', label: 'High contrast', icon: ContrastIcon },
{ key: 'voice', label: 'Voice guidance', icon: Volume2Icon },
{ key: 'reduceMotion', label: 'Reduced motion', icon: WavesIcon }];


export function AccessibilityBar({ embedded = false }: {embedded?: boolean;}) {
  const settings = useSettings();

  return (
    <section
      aria-label="Accessibility options"
      className={embedded ? '' : 'rounded-2xl border border-line bg-surface p-3'}>
      
      {!embedded &&
      <h2 className="px-1 pb-2 text-sm font-bold uppercase tracking-wide text-muted">Make it easier to use</h2>
      }
      <div className="grid grid-cols-2 gap-2">
        {OPTIONS.map(({ key, label, icon: Icon }) => {
          const active = settings[key];
          return (
            <button
              key={key}
              type="button"
              aria-pressed={active}
              onClick={() => {
                settings.toggle(key);
                if (key === 'voice' && !active) settings.speak('Voice guidance is on.');
              }}
              className={`flex min-h-[56px] items-center gap-2 rounded-xl border px-3 py-2 text-left text-sm font-bold transition-colors duration-150 ease-smooth ${
              active ?
              'border-accent bg-accent text-accentInk' :
              'border-line bg-surface2 text-ink hover:border-accent'}`
              }>
              
              <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
              <span className="leading-tight">{label}</span>
            </button>);

        })}
      </div>
    </section>);

}