import React from 'react';
import { AccessibilityIcon, ArrowRightLeftIcon, DoorOpenIcon, MapPinIcon } from 'lucide-react';
import { ModeIcon } from './ModeIcon';
import { StatusPill } from './StatusPill';
import { modeMeta } from '../data/network';
import { formatDuration, formatTime } from '../utils/format';
import type { Route } from '../types/journey';

interface JourneyTimelineProps {
  route: Route;
  activeLegIndex?: number;
}

export function JourneyTimeline({ route, activeLegIndex = -1 }: JourneyTimelineProps) {
  return (
    <ol className="space-y-3" aria-label="Journey step by step">
      <li className="flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-accent/50 bg-accent/10 text-accent">
          <MapPinIcon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0 pt-1">
          <p className="text-sm font-semibold uppercase tracking-wide text-muted">Start · {formatTime(route.departAt)}</p>
          <p className="text-lg font-bold leading-snug text-ink">{route.origin}</p>
        </div>
      </li>

      {route.legs.map((leg, index) => {
        const meta = modeMeta(leg.mode);
        const active = index === activeLegIndex;
        const previous = route.legs[index - 1];
        return (
          <React.Fragment key={leg.id}>
            {previous &&
            <li className="ml-5 flex items-start gap-3 rounded-2xl border border-dashed border-line bg-surface2/60 px-4 py-3">
                <ArrowRightLeftIcon className="mt-0.5 h-5 w-5 shrink-0 text-info" aria-hidden="true" />
                <div className="min-w-0">
                  <p className="text-base font-bold text-ink">
                    Change at {previous.toStop} · {formatDuration(Math.max(0, leg.startMin - previous.endMin))} to
                    transfer
                  </p>
                  <p className="pt-0.5 text-sm leading-snug text-muted">
                    Step-free route to {leg.platform}. Floor lights and signs guide you the whole way.
                  </p>
                </div>
              </li>
            }

            <li
              className={`rounded-2xl border px-4 py-4 transition-colors duration-200 ease-smooth ${
              active ? 'border-accent bg-accent/[0.08]' : 'border-line bg-surface'}`
              }>
              
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-start gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-surface2 text-accent">
                    <ModeIcon mode={leg.mode} className="h-6 w-6" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold uppercase tracking-wide text-muted">{meta.name}</p>
                    <p className="truncate text-lg font-bold text-ink">{leg.line}</p>
                  </div>
                </div>
                <StatusPill status={leg.status} delayMin={leg.delayMin} className="shrink-0" />
              </div>

              <dl className="grid grid-cols-2 gap-3 pt-4">
                <div>
                  <dt className="text-sm text-muted">Leaves</dt>
                  <dd className="text-base font-bold text-ink">
                    {formatTime(leg.departAt)} · {leg.fromStop}
                  </dd>
                </div>
                <div>
                  <dt className="text-sm text-muted">Arrives</dt>
                  <dd className="text-base font-bold text-ink">
                    {formatTime(leg.arriveAt)} · {leg.toStop}
                  </dd>
                </div>
              </dl>

              <div className="mt-4 space-y-2 rounded-xl bg-surface2 px-3 py-3">
                <p className="flex items-start gap-2 text-sm text-ink">
                  <DoorOpenIcon className="mt-0.5 h-4 w-4 shrink-0 text-info" aria-hidden="true" />
                  <span>
                    <span className="font-semibold">{leg.platform}</span> — {leg.boarding}
                  </span>
                </p>
                <p className="flex items-start gap-2 text-sm text-muted">
                  <AccessibilityIcon className="mt-0.5 h-4 w-4 shrink-0 text-info" aria-hidden="true" />
                  <span>{leg.accessNote}</span>
                </p>
              </div>

              <p className="pt-3 text-sm text-muted">
                {leg.stops.length - 1} {leg.stops.length - 1 === 1 ? 'stop' : 'stops'} ·{' '}
                {formatDuration(leg.endMin - leg.startMin)} on board
              </p>
            </li>
          </React.Fragment>);

      })}

      <li className="flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-accent bg-accent text-accentInk">
          <MapPinIcon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0 pt-1">
          <p className="text-sm font-semibold uppercase tracking-wide text-muted">
            Arrive · {formatTime(route.arriveAt)}
          </p>
          <p className="text-lg font-bold leading-snug text-ink">{route.destination}</p>
        </div>
      </li>
    </ol>);

}