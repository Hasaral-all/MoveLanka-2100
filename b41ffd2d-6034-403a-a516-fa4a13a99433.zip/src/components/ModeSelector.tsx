import React from 'react';
import { MODES } from '../data/network';
import { ModeIcon } from './ModeIcon';
import type { ModeKey } from '../types/journey';

interface ModeSelectorProps {
  selected: ModeKey[];
  onChange: (modes: ModeKey[]) => void;
}

export function ModeSelector({ selected, onChange }: ModeSelectorProps) {
  const toggle = (mode: ModeKey) => {
    onChange(selected.includes(mode) ? selected.filter((m) => m !== mode) : [...selected, mode]);
  };

  return (
    <fieldset className="rounded-2xl border border-line bg-surface p-4">
      <legend className="px-1 text-base font-semibold text-ink">How would you like to travel?</legend>
      <p className="pb-3 pt-1 text-sm text-muted">Pick any you like, or leave all off to see every option.</p>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {MODES.map((mode) => {
          const active = selected.includes(mode.key);
          return (
            <button
              key={mode.key}
              type="button"
              aria-pressed={active}
              onClick={() => toggle(mode.key)}
              className={`flex min-h-[64px] items-start gap-3 rounded-xl border px-3 py-3 text-left transition-colors duration-150 ease-smooth ${
              active ? 'border-accent bg-accent/10' : 'border-line bg-surface2 hover:border-accent/60'}`
              }>
              
              <span
                className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                active ? 'bg-accent text-accentInk' : 'bg-bg text-accent'}`
                }>
                
                <ModeIcon mode={mode.key} />
              </span>
              <span className="min-w-0">
                <span className="block text-base font-semibold text-ink">{mode.name}</span>
                <span className="block text-sm leading-snug text-muted">{mode.blurb}</span>
              </span>
            </button>);

        })}
      </div>
    </fieldset>);

}