import React from 'react';
import { AlertTriangleIcon, CheckCircle2Icon } from 'lucide-react';
import type { RunStatus } from '../types/journey';

interface StatusPillProps {
  status: RunStatus;
  delayMin?: number;
  className?: string;
}

export function StatusPill({ status, delayMin = 0, className = '' }: StatusPillProps) {
  const delayed = status === 'delayed';
  const Icon = delayed ? AlertTriangleIcon : CheckCircle2Icon;
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-semibold ${
      delayed ? 'border-warn/60 bg-warn/10 text-warn' : 'border-accent/50 bg-accent/10 text-accent'} ${
      className}`}>
      
      <Icon className="h-4 w-4" aria-hidden="true" />
      {delayed ? `Delayed ${delayMin} min` : 'On time'}
    </span>);

}