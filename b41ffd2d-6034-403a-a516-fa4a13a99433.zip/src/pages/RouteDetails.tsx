import React, { useEffect, useMemo } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  BatteryChargingIcon,
  BookmarkCheckIcon,
  BookmarkIcon,
  ChevronRightIcon,
  PlayIcon,
  UsersIcon } from
'lucide-react';
import { AccessibilityPanel } from '../components/AccessibilityPanel';
import { AiAssistantCard } from '../components/AiAssistantCard';
import { JourneyTimeline } from '../components/JourneyTimeline';
import { ModeIcon } from '../components/ModeIcon';
import { StatusPill } from '../components/StatusPill';
import { ThemeToggle } from '../components/ThemeToggle';
import { useJourney } from '../contexts/JourneyContext';
import { useSettings } from '../contexts/SettingsContext';
import { formatDay, formatDuration, formatTime } from '../utils/format';

export function RouteDetails() {
  const navigate = useNavigate();
  const { routes, route, selectedRouteId, selectRoute, startJourney, started, live, isSaved, toggleSaved } =
  useJourney();
  const { speak } = useSettings();

  const alternative = useMemo(() => {
    const others = routes.filter((r) => r.id !== route?.id && r.status === 'on-time');
    if (others.length === 0) return null;
    return others.reduce((best, r) => r.totalMin < best.totalMin ? r : best, others[0]);
  }, [routes, route]);

  useEffect(() => {
    if (!route) return;
    speak(
      `${route.origin} to ${route.destination}. ${formatDuration(route.totalMin)}, arriving ${formatTime(
        route.arriveAt
      )}. ${route.status === 'delayed' ? `Delayed by ${route.delayMin} minutes.` : 'On time.'}`
    );
  }, [route, speak]);

  if (!route) return <Navigate to="/" replace />;

  const firstLeg = route.legs[0];
  const nextLeg = route.legs[1];
  const delayedLeg = route.legs.find((leg) => leg.status === 'delayed');
  const saved = isSaved(route.id);
  const earlierBy = alternative ? route.totalMin - alternative.totalMin : 0;

  const begin = () => {
    if (!started) startJourney();
    speak(`Journey started. Board ${firstLeg.line} at ${firstLeg.platform}.`);
    navigate('/live');
  };

  const facts = [
  { label: 'Departure', value: `${formatTime(route.departAt)} · ${firstLeg.fromStop}` },
  { label: 'Arrival', value: `${formatTime(route.arriveAt)} · ${route.destination}` },
  { label: 'Total journey', value: formatDuration(route.totalMin) },
  {
    label: 'Changes',
    value: route.legs.length === 1 ? 'No changes' : `${route.legs.length - 1} change · ${route.transferMin} min`
  },
  { label: 'Boarding', value: firstLeg.platform },
  {
    label: 'Next connection',
    value: nextLeg ? `${nextLeg.line} · ${formatTime(nextLeg.departAt)}` : 'Direct, no connection'
  }];


  return (
    <div className="mx-auto w-full max-w-lg pb-32 lg:max-w-6xl">
      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <button
          type="button"
          onClick={() => navigate('/')}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-line bg-surface text-ink">
          
          <ArrowLeftIcon className="h-5 w-5" aria-hidden="true" />
          <span className="sr-only">Back to journey search</span>
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-extrabold leading-tight text-ink">Your journey</h1>
          <p className="truncate text-sm text-muted">{formatDay(route.departAt)}</p>
        </div>
        <button
          type="button"
          aria-pressed={saved}
          onClick={() => {
            toggleSaved(route.id);
            speak(saved ? 'Journey removed from saved.' : 'Journey saved.');
          }}
          className={`flex min-h-[48px] shrink-0 items-center gap-2 rounded-xl border px-3 text-sm font-bold ${
          saved ? 'border-accent bg-accent text-accentInk' : 'border-line bg-surface text-ink'}`
          }>
          
          {saved ?
          <BookmarkCheckIcon className="h-5 w-5" aria-hidden="true" /> :

          <BookmarkIcon className="h-5 w-5" aria-hidden="true" />
          }
          <span className="hidden sm:inline">{saved ? 'Saved' : 'Save'}</span>
          <span className="sr-only">journey</span>
        </button>
        <ThemeToggle className="shrink-0" />
      </header>

      <div className="px-4 pt-4 lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(0,0.95fr)] lg:gap-8">
        <div className="space-y-4">
          <section className="rounded-2xl border border-line bg-surface p-5">
            <div className="flex items-center gap-2 text-lg font-extrabold text-ink">
              <span className="min-w-0 truncate">{route.origin}</span>
              <ArrowRightIcon className="h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
              <span className="min-w-0 truncate">{route.destination}</span>
            </div>

            <p className="pt-4 text-[2.5rem] font-extrabold leading-none tracking-tight text-accent">
              {formatDuration(route.totalMin)}
            </p>
            <p className="pt-2 text-base font-bold text-ink">
              {formatTime(route.departAt)} – {formatTime(route.arriveAt)}
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-4">
              <StatusPill status={route.status} delayMin={route.delayMin} />
              <span className="inline-flex items-center gap-2 rounded-full border border-line bg-surface2 px-3 py-1.5 text-sm font-bold text-ink">
                <UsersIcon className="h-4 w-4 text-muted" aria-hidden="true" />
                {route.crowding}
              </span>
              <span className="inline-flex items-center gap-2 rounded-full border border-line bg-surface2 px-3 py-1.5 text-sm font-bold text-ink">
                <BatteryChargingIcon className="h-4 w-4 text-muted" aria-hidden="true" />
                {route.energy}
              </span>
            </div>

            <ul className="flex flex-wrap items-center gap-2 pt-4">
              {route.legs.map((leg) =>
              <li
                key={leg.id}
                className="flex items-center gap-2 rounded-xl bg-surface2 px-3 py-2 text-sm font-bold text-ink">
                
                  <ModeIcon mode={leg.mode} className="h-4 w-4 text-accent" />
                  {leg.line}
                </li>
              )}
            </ul>

            <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-4 border-t border-line pt-4">
              {facts.map((fact) =>
              <div key={fact.label}>
                  <dt className="text-sm text-muted">{fact.label}</dt>
                  <dd className="pt-0.5 text-base font-bold leading-snug text-ink">{fact.value}</dd>
                </div>
              )}
            </dl>
          </section>

          {delayedLeg && (
          alternative && earlierBy > 0 ?
          <AiAssistantCard
            tone="alert"
            title="AI smart routing"
            message={`Your ${delayedLeg.line} is delayed by ${
            delayedLeg.delayMin} minutes. AI recommends the ${
            alternative.label.toLowerCase()} — an autonomous connection arriving ${earlierBy} minutes earlier, at ${formatTime(
              alternative.arriveAt
            )}.`}
            actionLabel={`Switch to the ${alternative.label.toLowerCase()}`}
            onAction={() => {
              selectRoute(alternative.id);
              speak(`Switched to the ${alternative.label}. Arriving ${formatTime(alternative.arriveAt)}.`);
            }} /> :


          <AiAssistantCard
            tone="alert"
            title="AI smart routing"
            message={`Your ${delayedLeg.line} is delayed by ${delayedLeg.delayMin} minutes. This is still the quickest option, so AI is holding your onward connection and will re-book you automatically if it changes.`} />)

          }

          {routes.length > 1 &&
          <section aria-label="Other ways to travel" className="space-y-2">
              <h2 className="px-1 text-base font-extrabold text-ink">Other ways to travel</h2>
              {routes.map((option) => {
              const active = option.id === (selectedRouteId ?? route.id);
              return (
                <button
                  key={option.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => selectRoute(option.id)}
                  className={`flex min-h-[72px] w-full items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-colors duration-150 ease-smooth ${
                  active ? 'border-accent bg-accent/[0.08]' : 'border-line bg-surface hover:border-accent'}`
                  }>
                  
                    <span className="flex shrink-0 items-center gap-1 text-accent">
                      {option.legs.map((leg) =>
                    <ModeIcon key={leg.id} mode={leg.mode} className="h-5 w-5" />
                    )}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-base font-extrabold text-ink">
                        {option.label} · {formatDuration(option.totalMin)}
                      </span>
                      <span className="block truncate text-sm text-muted">
                        {formatTime(option.departAt)} – {formatTime(option.arriveAt)} ·{' '}
                        {option.status === 'delayed' ? `delayed ${option.delayMin} min` : 'on time'}
                      </span>
                    </span>
                    <ChevronRightIcon className="h-5 w-5 shrink-0 text-muted" aria-hidden="true" />
                  </button>);

            })}
            </section>
          }
        </div>

        <div className="space-y-4 pt-6 lg:pt-0">
          <h2 className="px-1 text-base font-extrabold text-ink">Step by step</h2>
          <JourneyTimeline route={route} activeLegIndex={live?.legIndex ?? -1} />
          <AccessibilityPanel />
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto w-full max-w-lg lg:max-w-6xl">
          <button
            type="button"
            onClick={begin}
            className="flex min-h-[64px] w-full items-center justify-center gap-3 rounded-2xl bg-accent px-4 text-lg font-extrabold text-accentInk transition-colors duration-150 ease-smooth hover:opacity-90">
            
            <PlayIcon className="h-6 w-6" aria-hidden="true" />
            {started ? 'Back to live tracking' : 'Start journey'}
          </button>
        </div>
      </div>
    </div>);

}