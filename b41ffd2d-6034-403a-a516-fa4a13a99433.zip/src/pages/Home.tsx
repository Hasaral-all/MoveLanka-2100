import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AccessibilityIcon,
  ArrowDownUpIcon,
  CalendarIcon,
  ClockIcon,
  LeafIcon,
  SearchIcon,
  SparklesIcon,
  TrainFrontIcon,
  ZapIcon } from
'lucide-react';
import { AccessibilityBar } from '../components/AccessibilityBar';
import { ModeSelector } from '../components/ModeSelector';
import { ModeIcon } from '../components/ModeIcon';
import { ThemeToggle } from '../components/ThemeToggle';
import { POPULAR_PLACES } from '../data/network';
import { useJourney } from '../contexts/JourneyContext';
import { useSettings } from '../contexts/SettingsContext';
import { formatDuration, formatTime } from '../utils/format';
import type { PreferenceKey } from '../types/journey';

const PREF_ICON: Record<PreferenceKey, typeof ZapIcon> = {
  fastest: ZapIcon,
  smartest: SparklesIcon,
  energy: LeafIcon,
  accessible: AccessibilityIcon
};

function greeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

export function Home() {
  const navigate = useNavigate();
  const { search, setSearch, previewRoutes, runSearch, selectRoute } = useJourney();
  const { speak } = useSettings();

  const [datePart, timePart] = search.dateTime.split('T');

  const recommended = useMemo(() => {
    const onTime = previewRoutes.filter((r) => r.status === 'on-time');
    const pool = onTime.length > 0 ? onTime : previewRoutes;
    return pool.reduce((best, r) => r.totalMin < best.totalMin ? r : best, pool[0]);
  }, [previewRoutes]);

  const go = (routeId?: string) => {
    const options = runSearch();
    const target = routeId && options.some((r) => r.id === routeId) ? routeId : options[0]?.id;
    if (target) selectRoute(target);
    speak(`${options.length} journeys found from ${search.from} to ${search.to}.`);
    navigate('/journey');
  };

  const swap = () => setSearch((prev) => ({ ...prev, from: prev.to, to: prev.from }));

  return (
    <div className="mx-auto w-full max-w-lg px-4 pb-14 pt-5 lg:max-w-6xl">
      <header className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-accent text-accentInk">
            <TrainFrontIcon className="h-6 w-6" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="truncate text-lg font-extrabold leading-none tracking-tight text-ink">LankaMove 2100</p>
            <p className="truncate pt-1 text-sm text-muted">Sri Lanka's unified transport network</p>
          </div>
        </div>
        <ThemeToggle className="shrink-0" />
      </header>

      <div className="lg:grid lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)] lg:gap-8">
        <div>
          <p className="pt-7 text-base font-semibold text-accent">{greeting()}, traveller</p>
          <h1 className="pt-1 text-[2rem] font-extrabold leading-tight tracking-tight text-ink">
            Where do you want to go?
          </h1>
          <p className="pt-2 text-base leading-snug text-muted">
            One plan across autonomous buses, smart trains, air transit and smart roads. We handle every change for
            you.
          </p>

          <form
            className="mt-6 space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              go();
            }}>
            
            <div className="rounded-2xl border border-line bg-surface p-4">
              <div className="space-y-3">
                <div>
                  <label htmlFor="from" className="block pb-1.5 text-base font-bold text-ink">
                    From
                  </label>
                  <input
                    id="from"
                    list="places"
                    value={search.from}
                    onChange={(event) => setSearch((prev) => ({ ...prev, from: event.target.value }))}
                    placeholder="e.g. Colombo Fort"
                    className="min-h-[56px] w-full rounded-xl border border-line bg-surface2 px-4 text-base font-semibold text-ink placeholder:text-muted/70" />
                  
                </div>

                <button
                  type="button"
                  onClick={swap}
                  className="flex min-h-[44px] items-center gap-2 rounded-xl border border-line bg-surface2 px-3 text-sm font-bold text-accent">
                  
                  <ArrowDownUpIcon className="h-4 w-4" aria-hidden="true" />
                  Swap
                  <span className="sr-only">starting point and destination</span>
                </button>

                <div>
                  <label htmlFor="to" className="block pb-1.5 text-base font-bold text-ink">
                    To
                  </label>
                  <input
                    id="to"
                    list="places"
                    value={search.to}
                    onChange={(event) => setSearch((prev) => ({ ...prev, to: event.target.value }))}
                    placeholder="e.g. Kandy"
                    className="min-h-[56px] w-full rounded-xl border border-line bg-surface2 px-4 text-base font-semibold text-ink placeholder:text-muted/70" />
                  
                </div>
                <datalist id="places">
                  {POPULAR_PLACES.map((place) =>
                  <option key={place} value={place} />
                  )}
                </datalist>
              </div>

              <div className="grid grid-cols-1 gap-3 pt-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="date" className="flex items-center gap-2 pb-1.5 text-base font-bold text-ink">
                    <CalendarIcon className="h-4 w-4 text-muted" aria-hidden="true" />
                    Date
                  </label>
                  <input
                    id="date"
                    type="date"
                    value={datePart}
                    onChange={(event) =>
                    setSearch((prev) => ({ ...prev, dateTime: `${event.target.value}T${timePart}` }))
                    }
                    className="min-h-[56px] w-full rounded-xl border border-line bg-surface2 px-4 text-base font-semibold text-ink" />
                  
                </div>
                <div>
                  <label htmlFor="time" className="flex items-center gap-2 pb-1.5 text-base font-bold text-ink">
                    <ClockIcon className="h-4 w-4 text-muted" aria-hidden="true" />
                    Leaving at
                  </label>
                  <input
                    id="time"
                    type="time"
                    value={timePart}
                    onChange={(event) =>
                    setSearch((prev) => ({ ...prev, dateTime: `${datePart}T${event.target.value}` }))
                    }
                    className="min-h-[56px] w-full rounded-xl border border-line bg-surface2 px-4 text-base font-semibold text-ink" />
                  
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="flex min-h-[64px] w-full items-center justify-center gap-3 rounded-2xl bg-accent px-4 text-lg font-extrabold text-accentInk transition-colors duration-150 ease-smooth hover:opacity-90">
              
              <SearchIcon className="h-6 w-6" aria-hidden="true" />
              Find journey
            </button>
          </form>
        </div>

        <div className="mt-8 space-y-4 lg:mt-[7.75rem]">
          <section aria-label="AI recommended journeys" className="rounded-2xl border border-info/60 bg-info/[0.07] p-4">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-info text-infoInk">
                <SparklesIcon className="h-5 w-5" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <h2 className="text-base font-extrabold text-info">AI recommended journey</h2>
                <p className="pt-1 text-[0.95rem] leading-snug text-ink">
                  {recommended ?
                  `${search.from} to ${search.to} in ${formatDuration(recommended.totalMin)} using ${
                  recommended.tagline}. Leaves ${
                  formatTime(recommended.departAt)}, arrives ${formatTime(recommended.arriveAt)}.` :
                  'Enter a start and destination to see suggestions.'}
                </p>
              </div>
            </div>

            <ul className="space-y-2 pt-4">
              {previewRoutes.map((option) => {
                const Icon = PREF_ICON[option.preference];
                const best = option.id === recommended?.id;
                return (
                  <li key={option.id}>
                    <button
                      type="button"
                      onClick={() => go(option.id)}
                      className="flex min-h-[76px] w-full items-center gap-3 rounded-xl border border-line bg-surface px-3 py-3 text-left transition-colors duration-150 ease-smooth hover:border-accent">
                      
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-surface2 text-accent">
                        <Icon className="h-6 w-6" aria-hidden="true" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex flex-wrap items-center gap-2">
                          <span className="text-base font-extrabold text-ink">{option.label}</span>
                          {best &&
                          <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-extrabold uppercase tracking-wide text-accentInk">
                              Best
                            </span>
                          }
                        </span>
                        <span className="block truncate text-sm text-muted">{option.tagline}</span>
                        <span className="flex items-center gap-1.5 pt-1 text-accent">
                          {option.legs.map((leg) =>
                          <ModeIcon key={leg.id} mode={leg.mode} className="h-4 w-4" />
                          )}
                          <span className="pl-1 text-sm font-semibold text-muted">{option.energy}</span>
                        </span>
                      </span>
                      <span className="shrink-0 text-right">
                        <span className="block text-lg font-extrabold text-ink">
                          {formatDuration(option.totalMin)}
                        </span>
                        <span className={`block text-sm font-bold ${option.status === 'delayed' ? 'text-warn' : 'text-accent'}`}>
                          {option.status === 'delayed' ? `+${option.delayMin} min` : 'On time'}
                        </span>
                      </span>
                    </button>
                  </li>);

              })}
            </ul>
          </section>

          <ModeSelector selected={search.modes} onChange={(modes) => setSearch((prev) => ({ ...prev, modes }))} />

          <AccessibilityBar />

          <p className="px-1 text-sm leading-snug text-muted">
            Vehicle positions, delays and arrival times in this prototype are simulated island network data.
          </p>
        </div>
      </div>
    </div>);

}