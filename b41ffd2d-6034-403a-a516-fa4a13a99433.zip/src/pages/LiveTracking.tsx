import React, { useEffect, useRef, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import {
  ArrowRightLeftIcon,
  CheckCircle2Icon,
  LifeBuoyIcon,
  ListIcon,
  MapPinIcon,
  NavigationIcon,
  Volume2Icon,
  VolumeXIcon } from
'lucide-react';
import { AccessibilityPanel } from '../components/AccessibilityPanel';
import { EmergencySheet } from '../components/EmergencySheet';
import { ModeIcon } from '../components/ModeIcon';
import { SmartCityMap } from '../components/SmartCityMap';
import { StatusPill } from '../components/StatusPill';
import { ThemeToggle } from '../components/ThemeToggle';
import { modeMeta } from '../data/network';
import { useJourney } from '../contexts/JourneyContext';
import { useSettings } from '../contexts/SettingsContext';
import { formatDuration, formatTime } from '../utils/format';

export function LiveTracking() {
  const navigate = useNavigate();
  const { route, live, started, startJourney, endJourney } = useJourney();
  const { voice, toggle, speak } = useSettings();
  const [assistOpen, setAssistOpen] = useState(false);
  const lastAnnounced = useRef<string>('');

  useEffect(() => {
    if (route && !started) startJourney();
  }, [route, started, startJourney]);

  useEffect(() => {
    if (!live || !route) return;
    const key = `${live.leg.id}-${live.currentStop}-${live.inTransfer}-${live.arrived}`;
    if (lastAnnounced.current === key) return;
    lastAnnounced.current = key;
    if (live.arrived) {
      speak(`You have arrived at ${route.destination}.`);
    } else if (live.inTransfer) {
      speak(`Change here. Your next vehicle is ${live.leg.line} from ${live.leg.platform}.`);
    } else {
      speak(`Now at ${live.currentStop}. Next stop ${live.nextStop}.`);
    }
  }, [live, route, speak]);

  if (!route) return <Navigate to="/" replace />;

  const activeLeg = live?.leg ?? route.legs[0];
  const nextLeg = live ? route.legs[live.legIndex + 1] : route.legs[1];
  const meta = modeMeta(activeLeg.mode);
  const progressPct = Math.round((live?.progress ?? 0) * 100);

  return (
    <div className="mx-auto w-full max-w-lg pb-36 lg:max-w-6xl">
      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-extrabold leading-tight text-ink">Live journey</h1>
          <p className="truncate text-sm text-muted">
            {route.origin} to {route.destination}
          </p>
        </div>
        <button
          type="button"
          aria-pressed={voice}
          onClick={() => {
            toggle('voice');
            if (!voice) window.setTimeout(() => speak('Voice guidance is on. I will call out every stop.'), 80);
          }}
          className={`flex min-h-[48px] shrink-0 items-center gap-2 rounded-xl border px-3 text-sm font-bold ${
          voice ? 'border-accent bg-accent text-accentInk' : 'border-line bg-surface text-ink'}`
          }>
          
          {voice ?
          <Volume2Icon className="h-5 w-5" aria-hidden="true" /> :

          <VolumeXIcon className="h-5 w-5" aria-hidden="true" />
          }
          Voice
        </button>
        <ThemeToggle className="shrink-0" />
      </header>

      <div className="space-y-4 px-4 pt-4 lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-8 lg:space-y-0">
        <div className="space-y-4">
          {live?.arrived ?
          <section className="rounded-2xl border border-accent bg-accent/[0.08] p-5">
              <CheckCircle2Icon className="h-8 w-8 text-accent" aria-hidden="true" />
              <h2 className="pt-3 text-2xl font-extrabold text-ink">You have arrived</h2>
              <p className="pt-1 text-base text-muted">
                {route.destination} · {formatTime(route.arriveAt)}. Doors open on the left, step-free to street level.
              </p>
              <button
              type="button"
              onClick={() => {
                endJourney();
                navigate('/');
              }}
              className="mt-4 min-h-[56px] w-full rounded-xl bg-accent text-base font-extrabold text-accentInk">
              
                Plan another journey
              </button>
            </section> :

          <section className="rounded-2xl border border-line bg-surface p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-start gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-accent text-accentInk">
                    <ModeIcon mode={activeLeg.mode} className="h-6 w-6" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-bold uppercase tracking-wide text-muted">
                      {live?.inTransfer ? 'Waiting to board' : `Currently travelling · ${meta.name}`}
                    </p>
                    <p className="truncate text-xl font-extrabold text-ink">{activeLeg.line}</p>
                    <p className="truncate text-sm text-muted">{activeLeg.vehicle}</p>
                  </div>
                </div>
                <StatusPill status={activeLeg.status} delayMin={activeLeg.delayMin} className="shrink-0" />
              </div>

              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-xl bg-surface2 px-4 py-4">
                  <p className="text-sm text-muted">Next stop</p>
                  <p className="pt-1 text-xl font-extrabold leading-tight text-ink">{live?.nextStop ?? '—'}</p>
                  <p className="pt-1 text-base font-bold text-accent">
                    ETA {formatDuration(live?.minutesToNextStop ?? 0)}
                  </p>
                </div>
                <div className="rounded-xl bg-surface2 px-4 py-4">
                  <p className="text-sm text-muted">Arriving {route.destination}</p>
                  <p className="pt-1 text-[1.75rem] font-extrabold leading-none text-accent">
                    {formatDuration(live?.minutesToArrival ?? route.totalMin)}
                  </p>
                  <p className="pt-1 text-base font-bold text-ink">at {formatTime(route.arriveAt)}</p>
                </div>
              </div>

              <p className="flex items-start gap-2 pt-4 text-sm text-ink">
                <MapPinIcon className="mt-0.5 h-4 w-4 shrink-0 text-info" aria-hidden="true" />
                <span>
                  {live?.inTransfer ?
                `Board at ${activeLeg.platform}. ${activeLeg.boarding}.` :
                `You are near ${live?.currentStop ?? route.origin} · getting off at ${activeLeg.toStop}`}
                </span>
              </p>
            </section>
          }

          <SmartCityMap route={route} live={live} />
        </div>

        <div className="space-y-4">
          <section aria-label="Journey progress" className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-base font-extrabold text-ink">Journey progress</p>
              <p className="text-base font-extrabold text-accent">{progressPct}%</p>
            </div>
            <div
              className="mt-3 h-3 w-full overflow-hidden rounded-full bg-surface2"
              role="progressbar"
              aria-valuenow={progressPct}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Journey progress">
              
              <div
                className="h-full rounded-full bg-accent transition-[width] duration-300 ease-smooth"
                style={{ width: `${progressPct}%` }} />
              
            </div>
            <dl className="grid grid-cols-2 gap-3 pt-4">
              <div>
                <dt className="text-sm text-muted">You are here</dt>
                <dd className="text-base font-bold leading-snug text-ink">{live?.currentStop ?? route.origin}</dd>
              </div>
              <div>
                <dt className="text-sm text-muted">Destination</dt>
                <dd className="text-base font-bold leading-snug text-ink">{route.destination}</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-2xl border border-line bg-surface p-5">
            <h2 className="flex items-center gap-2 text-base font-extrabold text-ink">
              <ArrowRightLeftIcon className="h-5 w-5 text-info" aria-hidden="true" />
              Next connection
            </h2>
            {nextLeg && live ?
            <div className="pt-3">
                <p className="text-lg font-extrabold text-ink">{nextLeg.line}</p>
                <p className="pt-1 text-base text-muted">
                  Change at {live.leg.toStop === nextLeg.fromStop ? nextLeg.fromStop : live.leg.toStop} ·{' '}
                  {nextLeg.platform}
                </p>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-surface2 px-3 py-3">
                    <p className="text-sm text-muted">{live.inTransfer ? 'Departs in' : 'Transfer time'}</p>
                    <p className="text-base font-extrabold text-ink">
                      {live.inTransfer ?
                    formatDuration(live.transferMinutesLeft) :
                    formatDuration(Math.max(0, nextLeg.startMin - live.leg.endMin))}
                    </p>
                  </div>
                  <div className="rounded-xl bg-surface2 px-3 py-3">
                    <p className="text-sm text-muted">Departs at</p>
                    <p className="text-base font-extrabold text-ink">{formatTime(nextLeg.departAt)}</p>
                  </div>
                </div>
              </div> :

            <p className="pt-3 text-base text-muted">
                No more changes. This vehicle takes you all the way to {route.destination}.
              </p>
            }
          </section>

          <AccessibilityPanel />

          <p className="flex items-start gap-2 px-1 text-sm leading-snug text-muted">
            <NavigationIcon className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
            Simulated live data from the island network. Position, delay and ETA refresh every second.
          </p>
        </div>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <div className="mx-auto flex w-full max-w-lg items-center gap-3 lg:max-w-6xl">
          <button
            type="button"
            onClick={() => navigate('/journey')}
            className="flex min-h-[60px] flex-1 items-center justify-center gap-2 rounded-2xl bg-accent px-3 text-base font-extrabold text-accentInk">
            
            <ListIcon className="h-5 w-5" aria-hidden="true" />
            Journey details
          </button>
          <button
            type="button"
            onClick={() => setAssistOpen(true)}
            className="flex min-h-[60px] shrink-0 items-center justify-center gap-2 rounded-2xl border-2 border-danger bg-surface px-4 text-base font-extrabold text-danger">
            
            <LifeBuoyIcon className="h-5 w-5" aria-hidden="true" />
            Help
          </button>
        </div>
      </div>

      <EmergencySheet
        open={assistOpen}
        onClose={() => setAssistOpen(false)}
        location={live?.currentStop ?? route.origin}
        vehicle={activeLeg.vehicle} />
      
    </div>);

}