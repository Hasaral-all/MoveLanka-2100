export type ModeKey = 'bus' | 'train' | 'air' | 'road';

export type PreferenceKey = 'fastest' | 'smartest' | 'energy' | 'accessible';

export type RunStatus = 'on-time' | 'delayed';

export interface MapPoint {
  x: number;
  y: number;
}

export interface Leg {
  id: string;
  mode: ModeKey;
  line: string;
  vehicle: string;
  fromStop: string;
  toStop: string;
  /** Effective minutes from journey departure (delays already applied). */
  startMin: number;
  endMin: number;
  departAt: Date;
  arriveAt: Date;
  platform: string;
  boarding: string;
  /** Ordered stop names; always the same length as `path`. */
  stops: string[];
  path: MapPoint[];
  status: RunStatus;
  delayMin: number;
  accessNote: string;
}

export interface Route {
  id: string;
  preference: PreferenceKey;
  label: string;
  tagline: string;
  origin: string;
  destination: string;
  departAt: Date;
  arriveAt: Date;
  totalMin: number;
  legs: Leg[];
  transferMin: number;
  stepFree: boolean;
  crowding: 'Quiet' | 'Moderate' | 'Busy';
  energy: string;
  status: RunStatus;
  delayMin: number;
}

export interface SearchParams {
  from: string;
  to: string;
  dateTime: string;
  modes: ModeKey[];
}