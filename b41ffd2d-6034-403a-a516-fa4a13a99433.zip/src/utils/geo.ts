import type { MapPoint } from '../types/journey';

export function toPathD(points: MapPoint[]): string {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x} ${p.y}`).join(' ');
}

export function polylineLength(points: MapPoint[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i += 1) {
    total += Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
  }
  return total;
}

/** Point at fraction `t` (0-1) along a polyline. */
export function pointAlong(points: MapPoint[], t: number): MapPoint {
  if (points.length === 0) return { x: 0, y: 0 };
  if (points.length === 1) return points[0];
  const clamped = Math.min(1, Math.max(0, t));
  const target = polylineLength(points) * clamped;
  let walked = 0;
  for (let i = 1; i < points.length; i += 1) {
    const segment = Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y);
    if (walked + segment >= target || i === points.length - 1) {
      const local = segment === 0 ? 0 : (target - walked) / segment;
      return {
        x: points[i - 1].x + (points[i].x - points[i - 1].x) * local,
        y: points[i - 1].y + (points[i].y - points[i - 1].y) * local
      };
    }
    walked += segment;
  }
  return points[points.length - 1];
}