import { format } from 'date-fns';

export function formatTime(date: Date): string {
  return format(date, 'h:mm a');
}

export function formatDay(date: Date): string {
  return format(date, 'EEE d MMM');
}

/** Plain-language duration, e.g. "1 hr 12 min". */
export function formatDuration(totalMinutes: number): string {
  const mins = Math.max(0, Math.round(totalMinutes));
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  if (hours === 0) return `${rest} min`;
  if (rest === 0) return `${hours} hr`;
  return `${hours} hr ${rest} min`;
}

export function toDateTimeInputValue(date: Date): string {
  return format(date, "yyyy-MM-dd'T'HH:mm");
}