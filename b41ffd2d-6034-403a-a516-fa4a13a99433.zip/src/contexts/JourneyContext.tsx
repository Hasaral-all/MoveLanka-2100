import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { buildRoutes } from '../data/network';
import { toDateTimeInputValue } from '../utils/format';
import { useScreenInit } from '../useScreenInit.js';
import type { Leg, Route, SearchParams } from '../types/journey';

interface ScreenInit {
  seed?: boolean;
  routeId?: string;
  started?: boolean;
  elapsedMin?: number;
}

/** 1 real second of the prototype = 2 simulated journey minutes. */
const SIM_MINUTES_PER_SECOND = 2;

export interface LiveState {
  leg: Leg;
  legIndex: number;
  legFraction: number;
  progress: number;
  currentStop: string;
  nextStop: string;
  minutesToArrival: number;
  minutesToNextStop: number;
  inTransfer: boolean;
  transferMinutesLeft: number;
  arrived: boolean;
}

interface JourneyValue {
  search: SearchParams;
  setSearch: React.Dispatch<React.SetStateAction<SearchParams>>;
  /** Options for the search as it currently stands, used by the AI assistant on home. */
  previewRoutes: Route[];
  routes: Route[];
  route: Route | null;
  selectedRouteId: string | null;
  runSearch: (override?: Partial<SearchParams>) => Route[];
  selectRoute: (id: string) => void;
  savedIds: string[];
  isSaved: (id: string) => boolean;
  toggleSaved: (id: string) => void;
  started: boolean;
  startJourney: () => void;
  endJourney: () => void;
  elapsedMin: number;
  live: LiveState | null;
}

const JourneyContext = createContext<JourneyValue | null>(null);

function defaultSearch(): SearchParams {
  const now = new Date();
  now.setMinutes(now.getMinutes() + 15);
  return {
    from: 'Colombo Fort',
    to: 'Kandy',
    dateTime: toDateTimeInputValue(now),
    modes: []
  };
}

const INITIAL_SEARCH = defaultSearch();

function computeLive(route: Route, elapsedMin: number): LiveState {
  const legs = route.legs;
  const clamped = Math.min(elapsedMin, route.totalMin);
  let legIndex = legs.findIndex((leg) => clamped <= leg.endMin);
  if (legIndex === -1) legIndex = legs.length - 1;

  const leg = legs[legIndex];
  const inTransfer = clamped < leg.startMin;
  const span = Math.max(1, leg.endMin - leg.startMin);
  const legFraction = Math.min(1, Math.max(0, (clamped - leg.startMin) / span));

  const stopCount = leg.stops.length;
  const segments = Math.max(1, stopCount - 1);
  const stopIndex = Math.min(segments, Math.floor(legFraction * segments + 0.0001));
  const nextIndex = Math.min(stopCount - 1, stopIndex + 1);
  const minutesToNextStop = Math.max(
    0,
    Math.ceil(leg.startMin + (stopIndex + 1) / segments * span - clamped)
  );

  return {
    leg,
    legIndex,
    legFraction,
    progress: Math.min(1, clamped / route.totalMin),
    currentStop: inTransfer ? leg.fromStop : leg.stops[stopIndex],
    nextStop: inTransfer ? leg.stops[Math.min(1, stopCount - 1)] : leg.stops[nextIndex],
    minutesToArrival: Math.max(0, Math.ceil(route.totalMin - clamped)),
    minutesToNextStop,
    inTransfer,
    transferMinutesLeft: Math.max(0, Math.ceil(leg.startMin - clamped)),
    arrived: clamped >= route.totalMin
  };
}

export function JourneyProvider({
  children,
  delayOnFastest = true



}: {children: React.ReactNode;delayOnFastest?: boolean;}) {
  const screenInit = useScreenInit() as ScreenInit;

  const [search, setSearch] = useState<SearchParams>(INITIAL_SEARCH);
  const [routes, setRoutes] = useState<Route[]>(() =>
  screenInit.seed ? buildRoutes(INITIAL_SEARCH, delayOnFastest) : []
  );
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(() =>
  screenInit.seed ? screenInit.routeId ?? 'fastest' : null
  );
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [startedAt, setStartedAt] = useState<number | null>(() =>
  screenInit.started ? Date.now() - (screenInit.elapsedMin ?? 0) / SIM_MINUTES_PER_SECOND * 1000 : null
  );
  const [elapsedMin, setElapsedMin] = useState(() => screenInit.started ? screenInit.elapsedMin ?? 0 : 0);

  const runSearch = useCallback(
    (override?: Partial<SearchParams>) => {
      const params = { ...search, ...override };
      if (override) setSearch(params);
      const next = buildRoutes(params, delayOnFastest);
      setRoutes(next);
      setSelectedRouteId((prev) => next.some((r) => r.id === prev) ? prev : next[0]?.id ?? null);
      setStartedAt(null);
      setElapsedMin(0);
      return next;
    },
    [search, delayOnFastest]
  );

  const previewRoutes = useMemo(() => buildRoutes(search, delayOnFastest), [search, delayOnFastest]);

  const route = useMemo(
    () => routes.find((r) => r.id === selectedRouteId) ?? routes[0] ?? null,
    [routes, selectedRouteId]
  );

  const startJourney = useCallback(() => {
    setStartedAt(Date.now());
    setElapsedMin(0);
  }, []);

  const endJourney = useCallback(() => {
    setStartedAt(null);
    setElapsedMin(0);
  }, []);

  const toggleSaved = useCallback((id: string) => {
    setSavedIds((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);
  }, []);

  const isSaved = useCallback((id: string) => savedIds.includes(id), [savedIds]);

  useEffect(() => {
    if (startedAt === null || !route) return;
    const tick = () => {
      const minutes = (Date.now() - startedAt) / 1000 * SIM_MINUTES_PER_SECOND;
      setElapsedMin(Math.min(minutes, route.totalMin));
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [startedAt, route]);

  const live = useMemo(
    () => route && startedAt !== null ? computeLive(route, elapsedMin) : null,
    [route, startedAt, elapsedMin]
  );

  const value = useMemo<JourneyValue>(
    () => ({
      search,
      setSearch,
      previewRoutes,
      routes,
      route,
      selectedRouteId,
      runSearch,
      selectRoute: setSelectedRouteId,
      savedIds,
      isSaved,
      toggleSaved,
      started: startedAt !== null,
      startJourney,
      endJourney,
      elapsedMin,
      live
    }),
    [
    search,
    previewRoutes,
    routes,
    route,
    selectedRouteId,
    runSearch,
    savedIds,
    isSaved,
    toggleSaved,
    startedAt,
    startJourney,
    endJourney,
    elapsedMin,
    live]

  );

  return <JourneyContext.Provider value={value}>{children}</JourneyContext.Provider>;
}

export function useJourney(): JourneyValue {
  const ctx = useContext(JourneyContext);
  if (!ctx) throw new Error('useJourney must be used inside JourneyProvider');
  return ctx;
}