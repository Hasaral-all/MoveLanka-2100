import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

export type ThemeMode = 'light' | 'dark';

export interface AccessibilitySettings {
  largeText: boolean;
  highContrast: boolean;
  reduceMotion: boolean;
  voice: boolean;
}

interface SettingsValue extends AccessibilitySettings {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
  toggle: (key: keyof AccessibilitySettings) => void;
  speak: (text: string) => void;
}

const SettingsContext = createContext<SettingsValue | null>(null);

interface SettingsProviderProps {
  children: React.ReactNode;
  initialTheme?: ThemeMode;
  initialHighContrast?: boolean;
  initialLargeText?: boolean;
}

export function SettingsProvider({
  children,
  initialTheme = 'light',
  initialHighContrast = false,
  initialLargeText = false
}: SettingsProviderProps) {
  const [theme, setTheme] = useState<ThemeMode>(initialTheme);
  const [settings, setSettings] = useState<AccessibilitySettings>({
    largeText: initialLargeText,
    highContrast: initialHighContrast,
    reduceMotion: false,
    voice: false
  });

  useEffect(() => setTheme(initialTheme), [initialTheme]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.classList.toggle('large-text', settings.largeText);
    root.classList.toggle('hc', settings.highContrast);
    root.classList.toggle('reduce-motion', settings.reduceMotion);
  }, [theme, settings.largeText, settings.highContrast, settings.reduceMotion]);

  const speak = useCallback(
    (text: string) => {
      if (!settings.voice) return;
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    },
    [settings.voice]
  );

  const toggle = useCallback((key: keyof AccessibilitySettings) => {
    setSettings((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      if (key === 'voice' && !next.voice && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      return next;
    });
  }, []);

  const toggleTheme = useCallback(() => setTheme((prev) => prev === 'dark' ? 'light' : 'dark'), []);

  const value = useMemo<SettingsValue>(
    () => ({ ...settings, theme, setTheme, toggleTheme, toggle, speak }),
    [settings, theme, toggleTheme, toggle, speak]
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsValue {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used inside SettingsProvider');
  return ctx;
}