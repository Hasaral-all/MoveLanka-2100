export const manifest = {
  screens: {
    scr_39920d: { name: "Home – Plan journey", route: "/", position: { "x": 160, "y": 220 } },
    scr_rj8nmo: { name: "Home – Dark mode", route: "/", state: { "theme": "dark" }, position: { "x": 1560, "y": 220 } },
    scr_wbxdbz: { name: "Home – Large text + contrast", route: "/", state: { "theme": "light", "largeText": true, "highContrast": true }, position: { "x": 2960, "y": 220 } },
    scr_x9yra4: { name: "Route details – Fastest", route: "/journey", state: { "seed": true, "routeId": "fastest" }, position: { "x": 160, "y": 2200 } },
    scr_j1wgqz: { name: "Route details – AI alternative", route: "/journey", state: { "seed": true, "routeId": "smartest" }, position: { "x": 1560, "y": 2200 } },
    scr_rw7izp: { name: "Route details – Dark mode", route: "/journey", state: { "seed": true, "routeId": "fastest", "theme": "dark" }, position: { "x": 2960, "y": 2200 } },
    scr_dszrh0: { name: "Live tracking – Departing", route: "/live", state: { "seed": true, "routeId": "fastest", "started": true, "elapsedMin": 6 }, position: { "x": 160, "y": 4180 } },
    scr_z7s7fr: { name: "Live tracking – Transfer", route: "/live", state: { "seed": true, "routeId": "fastest", "started": true, "elapsedMin": 95 }, position: { "x": 1560, "y": 4180 } },
    scr_mvpzp8: { name: "Live tracking – Dark mode", route: "/live", state: { "seed": true, "routeId": "fastest", "started": true, "elapsedMin": 40, "theme": "dark" }, position: { "x": 4360, "y": 4180 } },
    scr_b8f5ox: { name: "Live tracking – Arrived", route: "/live", state: { "seed": true, "routeId": "fastest", "started": true, "elapsedMin": 114 }, position: { "x": 2960, "y": 4180 } }
  },
  sections: {
    sec_eyavco: { name: "Home", x: 0, y: 0, width: 4320, height: 1180 },
    sec_wwtemv: { name: "Route details", x: 0, y: 1980, width: 4320, height: 1180 },
    sec_192v3i: { name: "Live tracking", x: 0, y: 3960, width: 5720, height: 1180 }
  },
  layers: [
  { kind: "section", id: "sec_eyavco", children: [
    { kind: "screen", id: "scr_39920d" },
    { kind: "screen", id: "scr_rj8nmo" },
    { kind: "screen", id: "scr_wbxdbz" }]
  },
  { kind: "section", id: "sec_wwtemv", children: [
    { kind: "screen", id: "scr_x9yra4" },
    { kind: "screen", id: "scr_j1wgqz" },
    { kind: "screen", id: "scr_rw7izp" }]
  },
  { kind: "section", id: "sec_192v3i", children: [
    { kind: "screen", id: "scr_dszrh0" },
    { kind: "screen", id: "scr_z7s7fr" },
    { kind: "screen", id: "scr_b8f5ox" },
    { kind: "screen", id: "scr_mvpzp8" }]
  }]

};