import { addMinutes } from 'date-fns';
import type { Leg, MapPoint, ModeKey, PreferenceKey, Route, SearchParams } from '../types/journey';

export interface ModeMeta {
  key: ModeKey;
  name: string;
  short: string;
  blurb: string;
}

export const MODES: ModeMeta[] = [
{ key: 'bus', name: 'Autonomous Bus', short: 'Bus', blurb: 'Driverless electric bus, kerb-level boarding' },
{ key: 'train', name: 'Smart Train', short: 'Train', blurb: 'Automated island rail, step-free at every hub' },
{ key: 'air', name: 'Air Transit', short: 'Air', blurb: 'Electric air shuttle between regional vertiports' },
{ key: 'road', name: 'Smart Road', short: 'Road pod', blurb: 'Private pod on an AI-managed expressway lane' }];


export interface PreferenceMeta {
  key: PreferenceKey;
  label: string;
  tagline: string;
}

export const PREFERENCES: PreferenceMeta[] = [
{ key: 'fastest', label: 'Fastest route', tagline: 'Quickest way door to door' },
{ key: 'smartest', label: 'Smartest route', tagline: 'AI monitored, fewest surprises' },
{ key: 'energy', label: 'Lowest energy', tagline: 'Solar rail, one vehicle all the way' },
{ key: 'accessible', label: 'Accessible route', tagline: 'Step-free with longer transfer time' }];


interface Town {
  name: string;
  lon: number;
  lat: number;
}

export const TOWNS: Town[] = [
{ name: 'Colombo Fort', lon: 79.85, lat: 6.93 },
{ name: 'Kandy', lon: 80.63, lat: 7.29 },
{ name: 'Galle', lon: 80.22, lat: 6.05 },
{ name: 'Jaffna', lon: 80.01, lat: 9.66 },
{ name: 'Negombo', lon: 79.84, lat: 7.21 },
{ name: 'Bandaranaike International Airport', lon: 79.88, lat: 7.18 },
{ name: 'Hambantota', lon: 81.12, lat: 6.12 },
{ name: 'Gampaha', lon: 80.0, lat: 7.09 },
{ name: 'Veyangoda', lon: 80.06, lat: 7.15 },
{ name: 'Kegalle', lon: 80.35, lat: 7.25 },
{ name: 'Kadugannawa', lon: 80.52, lat: 7.25 },
{ name: 'Peradeniya', lon: 80.6, lat: 7.26 },
{ name: 'Kurunegala', lon: 80.36, lat: 7.49 },
{ name: 'Chilaw', lon: 79.8, lat: 7.58 },
{ name: 'Puttalam', lon: 79.83, lat: 8.03 },
{ name: 'Anuradhapura', lon: 80.41, lat: 8.31 },
{ name: 'Dambulla', lon: 80.65, lat: 7.86 },
{ name: 'Polonnaruwa', lon: 81.0, lat: 7.94 },
{ name: 'Vavuniya', lon: 80.5, lat: 8.75 },
{ name: 'Kilinochchi', lon: 80.4, lat: 9.39 },
{ name: 'Mannar', lon: 79.92, lat: 8.98 },
{ name: 'Trincomalee', lon: 81.23, lat: 8.59 },
{ name: 'Batticaloa', lon: 81.7, lat: 7.71 },
{ name: 'Ampara', lon: 81.68, lat: 7.3 },
{ name: 'Badulla', lon: 81.06, lat: 6.99 },
{ name: 'Nuwara Eliya', lon: 80.77, lat: 6.97 },
{ name: 'Ratnapura', lon: 80.4, lat: 6.68 },
{ name: 'Kalutara', lon: 79.96, lat: 6.58 },
{ name: 'Bentota', lon: 80.0, lat: 6.42 },
{ name: 'Ambalangoda', lon: 80.05, lat: 6.24 },
{ name: 'Hikkaduwa', lon: 80.1, lat: 6.14 },
{ name: 'Matara', lon: 80.54, lat: 5.95 },
{ name: 'Tangalle', lon: 80.79, lat: 6.02 }];


export const POPULAR_PLACES = [
'Colombo Fort',
'Kandy',
'Galle',
'Jaffna',
'Negombo',
'Bandaranaike International Airport',
'Hambantota',
'Trincomalee',
'Matara',
'Anuradhapura'];


/** Island map projection: longitude/latitude to the 300 x 380 map viewBox. */
export function project(place: {lon: number;lat: number;}): MapPoint {
  return {
    x: Math.round(((place.lon - 79.5) * 88 + 40) * 10) / 10,
    y: Math.round(((9.9 - place.lat) * 70.73 + 40) * 10) / 10
  };
}

/** Stylised Sri Lanka coastline in the same projection. */
export const ISLAND_OUTLINE: MapPoint[] = [
{ lon: 79.72, lat: 8.0 },
{ lon: 79.7, lat: 7.0 },
{ lon: 79.85, lat: 6.5 },
{ lon: 80.1, lat: 6.0 },
{ lon: 80.5, lat: 5.95 },
{ lon: 81.2, lat: 6.1 },
{ lon: 81.7, lat: 6.4 },
{ lon: 81.88, lat: 7.4 },
{ lon: 81.6, lat: 8.2 },
{ lon: 81.35, lat: 8.6 },
{ lon: 81.2, lat: 9.1 },
{ lon: 80.9, lat: 9.5 },
{ lon: 80.5, lat: 9.8 },
{ lon: 80.0, lat: 9.8 },
{ lon: 79.8, lat: 9.4 },
{ lon: 79.9, lat: 8.9 },
{ lon: 79.75, lat: 8.4 }].
map(project);

function distanceKm(a: Town, b: Town): number {
  const meanLat = (a.lat + b.lat) / 2 * (Math.PI / 180);
  const dx = (a.lon - b.lon) * 110.6 * Math.cos(meanLat);
  const dy = (a.lat - b.lat) * 110.6;
  return Math.hypot(dx, dy);
}

export function findTown(name: string): Town | undefined {
  const query = name.trim().toLowerCase();
  if (!query) return undefined;
  return (
    TOWNS.find((t) => t.name.toLowerCase() === query) ?? (
    query.length > 2 ? TOWNS.find((t) => t.name.toLowerCase().includes(query)) : undefined));

}

/** Real towns that sit closest to the straight line between two places, in travel order. */
function corridorTowns(origin: Town, dest: Town, count: number): Town[] {
  const dx = dest.lon - origin.lon;
  const dy = dest.lat - origin.lat;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return [];
  return TOWNS.filter((t) => t.name !== origin.name && t.name !== dest.name).
  map((town) => {
    const t = ((town.lon - origin.lon) * dx + (town.lat - origin.lat) * dy) / len2;
    const px = origin.lon + dx * t;
    const py = origin.lat + dy * t;
    return { town, t, d: Math.hypot(town.lon - px, town.lat - py) };
  }).
  filter((s) => s.t > 0.08 && s.t < 0.92 && s.d < 0.45).
  sort((a, b) => a.d - b.d).
  slice(0, count).
  sort((a, b) => a.t - b.t).
  map((s) => s.town);
}

interface Node {
  name: string;
  point: MapPoint;
}

interface RawLeg {
  id: string;
  mode: ModeKey;
  line: string;
  vehicle: string;
  startOffset: number;
  endOffset: number;
  platform: string;
  boarding: string;
  accessNote: string;
  delayMin?: number;
  nodes: Node[];
}

interface RawRoute {
  id: string;
  preference: PreferenceKey;
  label: string;
  tagline: string;
  transferMin: number;
  stepFree: boolean;
  crowding: Route['crowding'];
  energy: string;
  legs: RawLeg[];
}

function finalise(raw: RawRoute, depart: Date, origin: string, destination: string): Route {
  let shift = 0;
  const legs: Leg[] = raw.legs.map((leg) => {
    const extra = leg.delayMin ?? 0;
    const startMin = leg.startOffset + shift + extra;
    const endMin = leg.endOffset + shift + extra;
    shift += extra;
    return {
      id: leg.id,
      mode: leg.mode,
      line: leg.line,
      vehicle: leg.vehicle,
      fromStop: leg.nodes[0].name,
      toStop: leg.nodes[leg.nodes.length - 1].name,
      startMin,
      endMin,
      departAt: addMinutes(depart, startMin),
      arriveAt: addMinutes(depart, endMin),
      platform: leg.platform,
      boarding: leg.boarding,
      stops: leg.nodes.map((n) => n.name),
      path: leg.nodes.map((n) => n.point),
      status: extra > 0 ? 'delayed' : 'on-time',
      delayMin: extra,
      accessNote: leg.accessNote
    };
  });

  const totalMin = legs[legs.length - 1].endMin;
  return {
    id: raw.id,
    preference: raw.preference,
    label: raw.label,
    tagline: raw.tagline,
    origin,
    destination,
    departAt: legs[0].departAt,
    arriveAt: addMinutes(depart, totalMin),
    totalMin,
    legs,
    transferMin: raw.transferMin,
    stepFree: raw.stepFree,
    crowding: raw.crowding,
    energy: raw.energy,
    status: shift > 0 ? 'delayed' : 'on-time',
    delayMin: shift
  };
}

/**
 * Builds the four AI journey options for a search across the 2100 island network.
 * Distances, stops and map geometry all come from real Sri Lankan coordinates.
 */
export function buildRoutes(params: SearchParams, delayOnFastest: boolean): Route[] {
  const parsed = new Date(params.dateTime);
  const depart = Number.isNaN(parsed.getTime()) ? new Date() : parsed;

  const originTown = findTown(params.from) ?? TOWNS[0];
  let destTown = findTown(params.to) ?? TOWNS[1];
  if (destTown.name === originTown.name) destTown = TOWNS[originTown.name === TOWNS[0].name ? 1 : 0];

  const originName = params.from.trim() || originTown.name;
  const destName = params.to.trim() || destTown.name;

  const originNode: Node = { name: originName, point: project(originTown) };
  const destNode: Node = { name: destName, point: project(destTown) };
  const hubPoint = project(destTown);
  const hubNode: Node = {
    name: `${destTown.name} Smart Transit Hub`,
    point: { x: hubPoint.x - 11, y: hubPoint.y + 9 }
  };

  const corridor = corridorTowns(originTown, destTown, 4);
  const nodes = corridor.map<Node>((town) => ({ name: town.name, point: project(town) }));
  const km = distanceKm(originTown, destTown);
  const base = Math.max(22, Math.round(km / 66.5 * 60));

  /** Beyond ~180 km the network flies you: electric air transit between regional vertiports. */
  const longHaul = km > 180;
  const firstLeg = longHaul ?
  {
    mode: 'air' as ModeKey,
    line: 'Air Transit · SkyLink 9',
    vehicle: 'Air pod AT-42',
    platform: 'Gate B2 · Vertiport deck',
    boarding: 'Ramp boarding, staff meet you at the gate',
    accessNote: 'Wheelchair spaces 2 and 3 are kept free',
    minutes: Math.max(20, Math.round(km / 240 * 60) + 12),
    tagline: 'Air Transit + Autonomous Bus',
    via: [] as Node[]
  } :
  {
    mode: 'train' as ModeKey,
    line: 'Smart Train · Express 2',
    vehicle: 'Train ST-214',
    platform: 'Platform 2 · Elevated deck',
    boarding: 'Level boarding at every door',
    accessNote: 'Step-free from street to seat, priority seats near door 1',
    minutes: base,
    tagline: 'Smart Train + Autonomous Bus',
    via: (nodes.length >= 3 ? [nodes[0], nodes[2]] : nodes.slice(0, 2)) as Node[]
  };
  const interchange: Node =
  nodes.length > 0 ?
  { name: `${nodes[nodes.length - 1].name} Interchange`, point: nodes[nodes.length - 1].point } :
  hubNode;
  const smartVia = nodes.length > 1 ? [nodes[0]] : [];

  const raw: RawRoute[] = [
  {
    id: 'fastest',
    preference: 'fastest',
    label: 'Fastest route',
    tagline: firstLeg.tagline,
    transferMin: 8,
    stepFree: true,
    crowding: 'Moderate',
    energy: longHaul ? '2.6 kWh per seat' : '1.4 kWh per seat',
    legs: [
    {
      id: 'fastest-1',
      mode: firstLeg.mode,
      line: firstLeg.line,
      vehicle: firstLeg.vehicle,
      startOffset: 0,
      endOffset: firstLeg.minutes,
      platform: firstLeg.platform,
      boarding: firstLeg.boarding,
      accessNote: firstLeg.accessNote,
      delayMin: delayOnFastest ? 6 : 0,
      nodes: [originNode, ...firstLeg.via, hubNode]
    },
    {
      id: 'fastest-2',
      mode: 'bus',
      line: 'Autonomous Bus · City Link',
      vehicle: 'Bus AB-07',
      startOffset: firstLeg.minutes + 8,
      endOffset: firstLeg.minutes + 23,
      platform: 'Bay C · Ground level',
      boarding: 'Ramp lowers automatically at the kerb',
      accessNote: 'Two wheelchair bays, audio stop announcements',
      nodes: [hubNode, destNode]
    }]

  },
  {
    id: 'smartest',
    preference: 'smartest',
    label: 'Smartest route',
    tagline: 'Smart Road pod + Smart Train',
    transferMin: 10,
    stepFree: true,
    crowding: 'Quiet',
    energy: '1.1 kWh per seat',
    legs: [
    {
      id: 'smartest-1',
      mode: 'road',
      line: 'Smart Road · Pod Lane E1',
      vehicle: 'Pod SR-512',
      startOffset: 0,
      endOffset: base + 3,
      platform: 'Pod Point 1 · Street level',
      boarding: 'Pod waits until you are seated and belted',
      accessNote: 'Seats four, plus one wheelchair space',
      nodes: [originNode, ...smartVia, interchange]
    },
    {
      id: 'smartest-2',
      mode: 'train',
      line: 'Smart Train · Hill Line',
      vehicle: 'Train ST-108',
      startOffset: base + 13,
      endOffset: base + 25,
      platform: 'Platform 1 · Same level as pods',
      boarding: 'Walk straight across the platform',
      accessNote: 'Quiet carriage with priority seating',
      nodes: [interchange, destNode]
    }]

  },
  {
    id: 'energy',
    preference: 'energy',
    label: 'Lowest energy',
    tagline: 'Solar Smart Train, no changes',
    transferMin: 0,
    stepFree: true,
    crowding: 'Quiet',
    energy: '0.6 kWh per seat · solar rail',
    legs: [
    {
      id: 'energy-1',
      mode: 'train',
      line: 'Smart Train · Solar Loop',
      vehicle: 'Train SL-061',
      startOffset: 0,
      endOffset: base + 34,
      platform: 'Platform 4 · Street level',
      boarding: 'Lift straight down to the platform',
      accessNote: 'Step-free throughout, staff on call in every carriage',
      nodes: [originNode, ...nodes, destNode]
    }]

  },
  {
    id: 'accessible',
    preference: 'accessible',
    label: 'Accessible route',
    tagline: 'Step-free train + assisted bus',
    transferMin: 12,
    stepFree: true,
    crowding: 'Quiet',
    energy: '1.5 kWh per seat',
    legs: [
    {
      id: 'accessible-1',
      mode: 'train',
      line: 'Smart Train · Assisted Service',
      vehicle: 'Train AS-330',
      startOffset: 0,
      endOffset: base + 6,
      platform: 'Platform 1 · Street level',
      boarding: 'A guide meets you at the entrance',
      accessNote: 'Wide doors, no gap to the platform, guide dog friendly',
      nodes: [originNode, ...nodes.slice(0, 3), hubNode]
    },
    {
      id: 'accessible-2',
      mode: 'bus',
      line: 'Autonomous Bus · Assisted Link',
      vehicle: 'Bus AL-19',
      startOffset: base + 18,
      endOffset: base + 36,
      platform: 'Bay A · Next to the lift',
      boarding: 'Ramp plus staff help, extra time to board',
      accessNote: 'Low floor, secure wheelchair anchors, large screens',
      nodes: [hubNode, destNode]
    }]

  }];


  const routes = raw.map((r) => finalise(r, depart, originName, destName));
  if (params.modes.length === 0) return routes;
  const matching = routes.filter((r) => r.legs.every((leg) => params.modes.includes(leg.mode)));
  return matching.length > 0 ? matching : routes;
}

export function modeMeta(mode: ModeKey): ModeMeta {
  return MODES.find((m) => m.key === mode) ?? MODES[0];
}